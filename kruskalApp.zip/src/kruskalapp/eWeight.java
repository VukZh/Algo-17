package kruskalapp;

public class eWeight { // конечная вершина с весом для матрицы вектора смежности 

    int vertex;
    int weight;

    eWeight(int v, int w) {
        vertex = v;
        weight = w;
    }

}
