package kruskalapp;

public class eWeight { // конечная вершина с весом для матрицы вектора смежности 

    public int vertex;
    public int weight;

    eWeight(int v, int w) {
        vertex = v;
        weight = w;
    }

}
