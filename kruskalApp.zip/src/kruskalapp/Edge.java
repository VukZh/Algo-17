package kruskalapp;

public class Edge { // ребро - данные V1 и V2 - вершины, W - вес

    int V1;
    int V2;
    int W;

    Edge(int v1, int v2, int w) {
        V1 = v1;
        V2 = v2;
        W = w;
    }
}
